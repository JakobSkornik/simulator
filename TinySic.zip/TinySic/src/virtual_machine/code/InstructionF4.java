package virtual_machine.code;

import virtual_machine.mnemonics.Mnemonic;

import javax.swing.*;

public class InstructionF4 extends Node {

    public String symbol;
    public int value;
    public boolean n;
    public boolean i;
    public boolean x;
    public boolean b = false;
    public boolean p = false;
    public boolean e;

    public InstructionF4(Mnemonic m, String symbol, boolean n, boolean i, boolean x) {

        super(m);
        this.symbol = symbol;
        this.n = n;
        this.i = i;
        this.x = x;
    }

    public InstructionF4(Mnemonic m, int value, boolean n, boolean i, boolean x) {

        super(m);
        this.value = value;
        this.n = n;
        this.i = i;
        this.x = x;
    }

    @Override
    public int length() { return 4;}

    @Override
    public void resolve(Code code) {

        String right_symbol = mnemonic.operandToString(this);
        int val = this.value;

        if (code.sym_tab.get(right_symbol) != null) {

            val = code.sym_tab.get(right_symbol);

            this.value = val + (x ? code.regs.getX() : 0);
        }

        if(this.value >= Code.MAX_ADDR || this.value < 0 - Code.MAX_ADDR) {

            JOptionPane.showMessageDialog(null, "INVALID ADDRESS" + value);
        }
    }

    @Override
    public void emitCode(byte[] data, int pos) {

        if (n && i) data[pos] = (byte)(this.mnemonic.opcode |= 0x03);
        else if (n && !i) data[pos] = (byte)(this.mnemonic.opcode |= 0x02);
        else if (!n && i) data[pos] = (byte)(this.mnemonic.opcode |= 0x01);
        else data[pos] = (byte)(this.mnemonic.opcode);

        int val = this.value & 0x2FFFFF;

        data[pos + 1] = (byte)(val >> 16);
        data[pos + 2] = (byte)(val >> 8);
        data[pos + 3] = (byte)(val);
    }
}
