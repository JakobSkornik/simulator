package virtual_machine.code;

import virtual_machine.mnemonics.Mnemonic;
import javax.swing.*;

public class InstructionF3 extends Node {

    public String symbol;
    public int value;
    public boolean n;
    public boolean i;
    public boolean x;
    public boolean b;
    public boolean p;
    public boolean e;

    public InstructionF3(Mnemonic m) {

        super(m);
    }

    public InstructionF3(Mnemonic m, String symbol, boolean n, boolean i, boolean x) {

        super(m);
        this.symbol = symbol;
        this.n = n;
        this.i = i;
        this.x = x;
    }

    public InstructionF3(Mnemonic m, int value, boolean n, boolean i, boolean x) {

        super(m);
        this.value = value;
        this.n = n;
        this.i = i;
        this.x = x;
    }

    @Override
    public int length() { return 3;}

    @Override
    public void resolve(Code code) {

        String right_symbol = mnemonic.operandToString(this);
        int val = this.value;

        if (code.sym_tab.get(right_symbol) != null) {

            val = code.sym_tab.get(right_symbol);

            int valPC = val - code.regs.PC();
            int valB = val - code.regs.getB();

            if (valPC >= -2048 && valPC <= 2047) { val = valPC; p = true;}
            else if (valB >= 0 && valB <= 4095) { val = valB; b = true;}

            this.value = val + (x ? code.regs.getX() : 0);
        }

        if(this.value >= Code.MAX_ADDR || this.value < 0 - Code.MAX_ADDR) {

            JOptionPane.showMessageDialog(null, "INVALID ADDRESS" + value);
        }
    }

    @Override
    public String operandToString() {

        return Integer.toString(this.value);
    }

    @Override
    public void emitCode(byte[] data, int pos) {

        if (n && i) data[pos] = (byte)(this.mnemonic.opcode |= 0x03);
        else if (n && !i) data[pos] = (byte)(this.mnemonic.opcode |= 0x02);
        else if (!n && i) data[pos] = (byte)(this.mnemonic.opcode |= 0x01);
        else data[pos] = (byte)(this.mnemonic.opcode);

        int val = this.value & 0x2FFF;

        if(x) val = ((1 << 15) | val);
        if(b) val = ((1 << 14) | val);
        if(p) val = ((1 << 13) | val);

        data[pos + 1] = (byte)(val >> 8);
        data[pos + 2] = (byte)(val);
    }
}
