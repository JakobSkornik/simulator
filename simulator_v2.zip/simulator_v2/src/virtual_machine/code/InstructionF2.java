package virtual_machine.code;

import virtual_machine.mnemonics.Mnemonic;

public class InstructionF2 extends Node {

    public String register;
    public String register_2;
    public int value;

    public InstructionF2(Mnemonic m, String r) {

        super(m);
        this.register = r;
    }

    public InstructionF2(Mnemonic m, int val) {

        super(m);
        this.value = val;
    }

    public InstructionF2(Mnemonic m, String r, int val) {

        super(m);
        this.register = r;
        this.value = val;
    }

    public InstructionF2(Mnemonic m, String r, String r2) {

        super(m);
        this.register = r;
        this.register_2 = r2;
    }

    @Override
    public int length() { return 2;}
}
